from enum import StrEnum


class PSUType(StrEnum):
    BUSINESS = "business"
    PERSONAL = "personal"
